import java.util.Scanner;
/** 
 * ACS-1904 Assignment X Question Y
 * @author 
*/

public class PlanetInfo{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String planet;
        
        Planets pl;
        Planets[] planets = Planets.values();
        
        // print terrestrial planets
        System.out.println("Terrestrial Planets:");
        
        for(Planets p : planets)
            if(!p.isJovian())
                System.out.println(p);
        
        // print jovian planets
        System.out.println("\nJovian Planets:");
        
        for(Planets p : planets)
            if(p.isJovian())
                System.out.println(p);
                
        // get panet info        
        System.out.println("\nEnter a planet name:");
        planet = scanner.next().toUpperCase();
        pl = Planets.valueOf(planet);
        
        System.out.print(pl + " has " + pl.getMoons());
        System.out.println(pl.getMoons() == 1 ? " moon." : " moons.");
        
        System.out.println("end of program");
    }
}
